<?php
/* @var $this UserController */
/* @var $data User */
?>

<div class="view">

	<b><?php echo CHtml::encode($data->getAttributeLabel('id')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->id), array('view', 'id'=>$data->id)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('user_type')); ?>:</b>
	<?php echo CHtml::encode($data->user_type); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('user_info')); ?>:</b>
	<?php echo CHtml::encode($data->user_info); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('user_perms')); ?>:</b>
	<?php echo CHtml::encode($data->user_perms); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('sup_user')); ?>:</b>
	<?php echo CHtml::encode($data->sup_user); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('user_name')); ?>:</b>
	<?php echo CHtml::encode($data->user_name); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('user_surname')); ?>:</b>
	<?php echo CHtml::encode($data->user_surname); ?>
	<br />

	<?php /*
	<b><?php echo CHtml::encode($data->getAttributeLabel('user_email')); ?>:</b>
	<?php echo CHtml::encode($data->user_email); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('salt_password')); ?>:</b>
	<?php echo CHtml::encode($data->salt_password); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('user_password')); ?>:</b>
	<?php echo CHtml::encode($data->user_password); ?>
	<br />

	*/ ?>

</div>